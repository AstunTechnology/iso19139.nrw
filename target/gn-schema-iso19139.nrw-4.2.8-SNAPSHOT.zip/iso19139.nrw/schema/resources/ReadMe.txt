
Validated with XSV 2.10, Xerces J 2.7.1 and XML Spy 2009 (2009-03-02, IGN / France - Nicolas Lesage / Marcellin Prudham)


**************************

Package "resources" from the ISO repository (http://standards.iso.org/ittf/PubliclyAvailableStandards/ISO_19139_Schemas/resources/)
downloaded 2009-03-02 and modified as follows:

schemaLocation http://www.opengis.net/gml/3.2 ../../../ISO_19136_Schemas/gml.xsd
AND http://www.w3.org/1999/xlink http://schemas.opengis.net/xlink/1.0.0/xlinks.xsd
replaced everywhere by
http://www.opengis.net/gml/3.2 ../../gml/gml.xsd
AND http://www.w3.org/1999/xlink ../../xlink/xlinks.xsd


